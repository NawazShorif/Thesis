close all;
clear all;
clc;
load train1.txt;
X = train1;
clear train1;
C = X(:,1);
X(:,1:2)=[];
%test data
load test1.txt;
tX = test1;
clear test1;
tC = tX(:,1);
tX(:,1:2)=[];
orC=C;
ortC=tC;
for i=1:220
        MI(i)= hs_mut_inf( X(:,i),C);
end
%%

    %===============MI=====================
    for i=1:220
        MI(i)= hs_mut_inf( X(:,i),C);
    end
  %%
  %===============nMI=====================
    for i=1:220
        xMI(i)=sqrt(hs_mut_inf( X(:,i),X(:,i)));
    end
    lC=sqrt(hs_mut_inf( C,C));
    for i=1:220
        nMI(i)=MI(i)/((xMI(i)*lC)+1e-40);
    end
    %%
     %===============1st Feature Selection=====================
    [value1,idx]=sort(nMI,'descend');
    ornMI=nMI;
    flag=[];
     clear S;
    flag=zeros(1,220);
    S=idx(:,1);
    flag(idx(1,1))=1;
    %%
     %===============2nd to 10th Feature Selection=====================
    for k=2:10
        Tmax=-1;
        Indx=0;
        for i=1:120
                if flag(idx(1,i))==0
                temp=0.0;
                [row col]=size(S);
                for j=1:col
                    temp=temp+hs_mut_inf( X(:,idx(1,i)),X(:,S(1,j)))/(xMI(i)*xMI(S(1,j))+1e-40);
                end
                temp=nMI(idx(1,i))-temp/col;
                if temp>Tmax
                    Tmax=temp;
                    Indx=idx(1,i);
                end
                end
        end
        flag(Indx)=1;
        S=[S Indx]
    end
    %%
    load nMI10.txt;
    S=nMI10;
    clear nMI10.txt;
    clear train_MI
    clear test_MI
    train_MI=[]
    test_MI=[]
    for y=1:10
        
        train_MI=[train_MI X(:,S(1,y))];
        test_MI=[test_MI tX(:,S(1,y))];
    end
    %%
    for i=1:size(train_MI, 2)
        train_MI(:,i)=scaledata(train_MI(:,i));
        test_MI(:,i)=scaledata(test_MI(:,i));
    end
    %%
    addpath('J:\libsvm-3.22\matlab');
    %%
    %=============== Calculate  best C & V ========================
%     bestcv=0; bestc=0; bestg=0;
%     for c = 1:30
%         for g = 0.01:0.01:3
%             cmd=['-v 10 -c ',num2str(c), ' -g ', num2str(g)];
%             cv = svmtrain(C, train_MI, cmd);
%             if(cv>=bestcv)
%                 bestcv=cv; bestc=c; bestg=g;
%             end
%             fprintf('%g   %g  %g (best c=%g, g=%g, rate=%g)\n', c, g, cv, bestc, bestg, bestcv);
%         end
%     end

   bestc=10;  
   bestg=3;   
   
   %%
    %=============== Calculate  Accuracy for test data =======================
    resultOrg=[];
    cmd=['-t 2 -c ',num2str(bestc), ' -g ', num2str(bestg)];
    for f=1:10
        model = svmtrain(C,train_MI(:,1:f),cmd);
        [predict_label, accuracy, dec_values] = svmpredict(tC, test_MI(:,1:f), model);
        resultOrg = [resultOrg accuracy(1)];
    end
    fullresult_nMI=result_analysis(resultOrg)

