function TTT=result_analysis(TT);
TTT=sort(TT);